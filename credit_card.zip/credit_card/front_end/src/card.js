import React from 'react';
import styled from 'styled-components';
import { Card as MUICard, CardContent, Typography } from '@material-ui/core';
import { AccountCircle, CreditCard } from '@material-ui/icons';

const CardContainer = styled.div`
  display: flex;
  justify-content: center;
  align-items: center;
  height: 100vh;
`;

const StyledCard = styled(MUICard)`
  width: 400px;
  height: 250px;
  display: flex;
  flex-direction: column;
  justify-content: space-between;
`;

const IconContainer = styled.div`
  display: flex;
  justify-content: space-between;
`;

const Card = () => {
  return (
    <CardContainer>
      <StyledCard>
        <CardContent>
          <IconContainer>
            <AccountCircle />
            <CreditCard />
          </IconContainer>
          <Typography variant="h5" component="h2">
            1234 5678 9012 3456
          </Typography>
          <Typography color="textSecondary" gutterBottom>
            John Doe
          </Typography>
          <Typography color="textSecondary">
            Expires: 12/22
          </Typography>
        </CardContent>
      </StyledCard>
    </CardContainer>
  );
};

export default Card;
