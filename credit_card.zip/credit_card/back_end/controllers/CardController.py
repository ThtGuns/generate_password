from flask import Flask, request, jsonify
from flask_cors import CORS
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from CardModel import Card, Base

app = Flask(__name__)
CORS(app)

engine = create_engine('sqlite:///database/card_data.db')
Base.metadata.bind = engine
DBSession = sessionmaker(bind=engine)

@app.route('/cards', methods=['GET'])
def get_all_cards():
    session = DBSession()
    cards = session.query(Card).all()
    session.close()
    return jsonify(cards=[c.__dict__ for c in cards])

@app.route('/cards', methods=['POST'])
def add_card():
    card_number = request.json['card_number']
    card_holder = request.json['card_holder']
    expiration_date = request.json['expiration_date']
    cvv = request.json['cvv']

    card = Card(card_number=card_number, card_holder=card_holder,
                expiration_date=expiration_date, cvv=cvv)
    
    session = DBSession()
    session.add(card)
    session.commit()
    session.close()

    return jsonify(card=card.__dict__)

if __name__ == '__main__':
    app.run()
    